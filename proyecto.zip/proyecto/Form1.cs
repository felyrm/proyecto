namespace proyecto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mnpedido_Click(object sender, EventArgs e)
        {
            Orden pedido = new Orden();
            pedido.MdiParent = this;
            pedido.Show();
        }

        private void nuevoTecnicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 tecnico = new Form2();
            tecnico.MdiParent = this;
            tecnico.Show();
        }
    }
}