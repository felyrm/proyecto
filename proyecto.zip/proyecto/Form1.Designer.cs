﻿namespace proyecto
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mningresar = new System.Windows.Forms.ToolStripMenuItem();
            this.mnpedido = new System.Windows.Forms.ToolStripMenuItem();
            this.tecnico = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mningresar});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mningresar
            // 
            this.mningresar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnpedido,
            this.tecnico});
            this.mningresar.Name = "mningresar";
            this.mningresar.Size = new System.Drawing.Size(76, 24);
            this.mningresar.Text = "Ingresar";
            // 
            // mnpedido
            // 
            this.mnpedido.Name = "mnpedido";
            this.mnpedido.Size = new System.Drawing.Size(224, 26);
            this.mnpedido.Text = "Pedido";
            this.mnpedido.Click += new System.EventHandler(this.mnpedido_Click);
            // 
            // tecnico
            // 
            this.tecnico.Name = "tecnico";
            this.tecnico.Size = new System.Drawing.Size(224, 26);
            this.tecnico.Text = "Nuevo tecnico";
            this.tecnico.Click += new System.EventHandler(this.nuevoTecnicoToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Aplicacion empresa";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem mningresar;
        private ToolStripMenuItem mnpedido;
        private ToolStripMenuItem tecnico;
    }
}